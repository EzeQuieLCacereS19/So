#include <utils/utils.h>

int main(int argc, char* argv[]) {

    log = log_create("memoria.log", "Memoria", true, LOG_LEVEL_DEBUG);
    char* puerto_servidor = "8002";

    conectar_componete("127.0.0.1", "8000", "Hola al modulo kernel desde la memoria");

    conectar_componete("127.0.0.1", "8001", "Hola al modulo cpu desde la memoria");
    
    iniciar_conecciones(puerto_servidor);
    
    conectar_componete("127.0.0.1", "8003", "Hola al modulo io desde la memoria");   

    return 0;
}
