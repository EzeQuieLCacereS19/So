#include <utils/utils.h>

int main(int argc, char* argv[]) {

    log = log_create("memoria.log", "Memoria", true, LOG_LEVEL_DEBUG);
    char* puerto_servidor = "8003";

    conectar_componete("127.0.0.1", "8000", "Hola al modulo kernel desde la io");

    conectar_componete("127.0.0.1", "8001", "Hola al modulo cpu desde la io");
        
    conectar_componete("127.0.0.1", "8002", "Hola al modulo memoria desde la io");   

    iniciar_conecciones(puerto_servidor);

    return 0;
}
