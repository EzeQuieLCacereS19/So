//OBJETIVOS:
//PLANIFICACION CORTA Y LARGA CON FIFO.
//ADMINISTRACION DE IO.
#include <kernel.h>
#include <commons/log.h> // Include for log_create

// Initialize the global log variable
t_log* log;

int main(int argc, char* argv[]) {
    log = log_create("kernel.log", "Kernel", true, LOG_LEVEL_DEBUG); // Initialize the log here

    int socket_servidor = iniciar_servidor(puertoServidor);
    log_debug(log, "Kernel iniciado en el puerto %s", puertoServidor);

    inicializarListaCpu();
    inicializarListasDeProcesos(); // Initialize the process lists

    // Example of adding a CPU for testing (optional, remove for dynamic connections)
    // For a real system, CPUs would connect to the kernel and get added.
    agregarCpuLista("127.0.0.1", "8001"); // Simulate one CPU connected

    while (1) {
        log_debug(log, "Esperando cliente...");
        int cliente = esperar_cliente(socket_servidor);
        if (cliente == -1) {
            log_error(log, "Error al esperar cliente.");
            continue;
        }
        log_debug(log, "Cliente conectado: FD %d", cliente);

        // Handle client in a separate thread for concurrent operations
        // For simplicity, directly calling it here. In a real kernel,
        // you'd typically spawn a thread for each client connection.
        manejarCliente(cliente); // This function now calls planificarProceso indirectly
        // The close(cliente) is handled inside manejarCliente when cod_op is -1

        // You could also call planificarProceso here periodically
        // (e.g., using a timer or a separate scheduling thread)
        // planificarProceso();
    }

    // Don't forget to destroy the process lists and log at the end of the program
    destruirListaDeProcesos(lista_procesos_nuevos);
    destruirListaDeProcesos(lista_procesos_listos);
    log_destroy(log);
    return 0;
}
